---
name: Petroleum Executive Portfolio
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#41474f'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#717880'
  outline-variant: '#c1c7d1'
  surface-tint: '#1d6298'
  primary: '#005388'
  on-primary: '#ffffff'
  primary-container: '#2b6ca3'
  on-primary-container: '#daeaff'
  inverse-primary: '#9acbff'
  secondary: '#52606a'
  on-secondary: '#ffffff'
  secondary-container: '#d3e2ee'
  on-secondary-container: '#56646f'
  tertiary: '#495258'
  on-tertiary: '#ffffff'
  tertiary-container: '#616a70'
  on-tertiary-container: '#e1eaf1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d0e4ff'
  primary-fixed-dim: '#9acbff'
  on-primary-fixed: '#001d34'
  on-primary-fixed-variant: '#004a79'
  secondary-fixed: '#d6e5f0'
  secondary-fixed-dim: '#bac8d4'
  on-secondary-fixed: '#0f1d26'
  on-secondary-fixed-variant: '#3b4952'
  tertiary-fixed: '#dbe4eb'
  tertiary-fixed-dim: '#bfc8ce'
  on-tertiary-fixed: '#141d22'
  on-tertiary-fixed-variant: '#3f484e'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  headline-hero:
    fontFamily: Work Sans
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
  headline-hero-mobile:
    fontFamily: Work Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Work Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg-mobile:
    fontFamily: Work Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-md:
    fontFamily: Work Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Work Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Work Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
  label-md:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  metadata:
    fontFamily: Work Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an executive, precision-engineered visual language tailored for high-impact analytical profiles within industrial operations, business intelligence, and technical consulting. 

The aesthetic is **Corporate Modern with Functional Minimalism**:
- **Demeanor:** Pragmatic, dependable, data-literate, and rigorous. It communicates structure, operational excellence, and analytical fidelity.
- **Visual Stance:** Crisp white environments layered with calibrated corporate petroleum blues and structural slate grays. Avoids decorative clutter in favor of structured data displays, scannable hierarchies, and purposeful micro-interactions.
- **Motion & Interaction Philosophy:** Interactions are deterministic, hardware-accelerated, and strictly CSS-driven (utilizing native `<details>`/`<summary>` accordion disclosures and pure CSS 3D/crossfade perspective shifts on portfolio project tiles).

## Colors

The color palette reflects operational precision through cold, technical corporate blues paired with high-legibility slate neutrals.

- **Primary (`#2B6CA3` - Petroleum Blue):** The anchor for brand authority, key action buttons, active navigation states, primary timeline markers, and focused interactive highlights.
- **Secondary (`#DCEBF7` - Header Ice Tint):** Dedicated to top-level hero surfaces, table head accents, and major structural boundary highlights.
- **Tertiary (`#EAF3FA` - Soft Water Accent):** Used for low-contrast badge surfaces, selected accordion tab fills, subtle metric card backgrounds, and hover fills.
- **Neutral Palette:**
  - **Main Canvas:** `#FFFFFF` (pure white for pristine paper-like portfolio readability).
  - **Primary Text:** `#1F2937` (slate-charcoal, offering high contrast without the harsh glare of `#000000`).
  - **Secondary Text:** `#4B5563` (cool graphite for subtitles, body paragraphs, and descriptive text).
  - **Muted Metadata:** `#6B7280` (lead text for dates, locations, and sub-labels) and `#9CA3AF` (captions, disabled states, and decorative borders).
- **Functional Stroke / Borders:** `#E5E7EB` to `#D1D5DB` provide deliberate structural division without high-contrast friction.

## Typography

Typography is set entirely in **Work Sans** across four specific weights (400 Regular, 500 Medium, 600 Semi-Bold, and 700 Bold) to maintain structural harmony and fast load times.

- **Hero & Section Headings (`700`, `600`):** Use tightened letter-spacing (`-0.02em`) to project confidence, authority, and modern editorial polish.
- **Data & Metric Displays (`700`):** Numerical callouts are prioritized using tabular numbers (`font-variant-numeric: tabular-nums`) for clean vertical scanning across KPI blocks.
- **Body & Descriptions (`400`):** Optimized for continuous reading with relaxed vertical metrics (`1.45` to `1.55` line-height ratio) and high legibility across `#1F2937` and `#4B5563`.
- **Labels, Chips & Captions (`500`, `600`):** Small sizes use slight positive tracking (`letter-spacing: +0.02em`) to ensure legibility when set against muted or colored pill backgrounds.

## Layout & Spacing

The portfolio is structured around a centralized fixed container constrained to a maximum content width of `1200px` (`max-width: 1200px; margin-inline: auto`).

- **Grid Architecture:** 12-column responsive layout with `1.5rem` (24px) gutters on desktop, collapsing to 6 columns on tablet and 1 column (vertical stack) on mobile.
- **Section Rhythm:** Major vertical sections are separated by `space-xl` (40px) or double-spaced (80px) intervals, maintaining comfortable breathing room between work history, education, BI project showcases, and technical toolsets.
- **Micro Spacing:** Spacing inside card components adheres strictly to a base 4px/8px modular rhythm (`space-sm` for tag arrays, `space-md` for internal panel padding, `space-lg` for section card buffers).

## Elevation & Depth

This design system uses a crisp, **Flat Contemporary** aesthetic relying on low-contrast structural borders and tonal layering rather than heavy drop shadows:

- **Level 0 (Flat Base):** Main viewport background (`#FFFFFF`).
- **Level 1 (Surface Containers):** Header section (`#DCEBF7`), project cards, and experience blocks use 1px perimeter borders in `#E5E7EB` with zero shadow.
- **Level 2 (Active / Hover States):** Hover states on cards employ an ambient, petroleum-tinted shadow (`0 8px 24px -4px rgba(43, 108, 163, 0.08)`) coupled with a border color shift to `#2B6CA3` to indicate active engagement.
- **Layer Stacking for Interactive Cards:** The pure CSS hover-flip and crossfade project tiles leverage 3D perspective transforms (`perspective: 1000px; transform-style: preserve-3d;`) without artificial skewing, retaining razor-sharp text clarity.

## Shapes

The geometric form language is balanced, modern, and friendly without becoming overly playful. Corner radii range strictly within **8px to 14px**:

- **Standard Elements (8px - `border-radius: 8px`):** Used for interactive buttons, input fields, accordion summaries, and technology pills.
- **Cards & Modules (12px - `border-radius: 12px`):** Standard for project showcase cards, metric highlights, and resume timeline entries.
- **Hero & Large Containers (14px - `border-radius: 14px`):** Applied to top-level featured banners, resume header blocks, and outer card wrappers.
- **Full Pill (`border-radius: 9999px`):** Reserved exclusively for status indicators (e.g., "Available for Hire") and compact category tags.

## Components

### 1. Buttons
- **Primary:** Background `#2B6CA3`, text `#FFFFFF`, border-radius 8px, font-weight 600. Hover state: background `#235784`, transform `translateY(-1px)`. Active: `translateY(0)`.
- **Secondary / Outline:** Border `1.5px solid #2B6CA3`, text `#2B6CA3`, transparent background. Hover state: background `#EAF3FA`.
- **Ghost:** Text `#4B5563`, no border. Hover state: background `#EAF3FA`, text `#2B6CA3`.

### 2. Badges & Chips
- **Skill Pill:** Background `#EAF3FA`, text `#2B6CA3`, border `1px solid rgba(43, 108, 163, 0.15)`, font-size 12px, font-weight 500, border-radius 8px, padding `4px 10px`.
- **Status Indicator:** Full pill, background `#EAF3FA`, text `#2B6CA3` with an inline 6px emerald circle pulse (`#10B981`) for active operational availability.

### 3. Accordions (Pure CSS Details / Summary)
- Built natively using HTML `<details>` and `<summary>` without JavaScript dependencies.
- **Summary:** Styled as a clean bar with border-radius 10px, background `#FFFFFF`, border `1px solid #E5E7EB`, padding `16px 20px`. Hover background `#EAF3FA`.
- **Indicator:** A custom CSS chevron rendered via pseudo-element `::after` with smooth transition (`transform: rotate(0deg)` to `rotate(180deg)` on `details[open] summary::after`).
- **Content:** Expands smoothly with CSS grid row animations (`grid-template-rows: 0fr` to `1fr`), revealing rich timeline notes, operational duties, and metric breakdowns.

### 4. Interactive Project Cards (Pure CSS Flip / Crossfade)
- **Structure:** Card container with `perspective: 1000px`, housing an inner wrapper with `transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)` and `transform-style: preserve-3d`.
- **Front Face:** White canvas, border-radius 12px, 1px `#E5E7EB` border. Displays project title, BI tool stack tags, KPI callout, and hero illustration/dashboard thumbnail.
- **Back Face (Flip State):** Background `#EAF3FA`, rotated `transform: rotateY(180deg)`, `backface-visibility: hidden`. Contains operational methodology, dataset size, transformation pipeline details, and a primary outbound link button.
- **Crossfade Variant:** For data-dense cards where flipping impairs legibility, an alternative pure CSS overlay card reveals data summaries on `:hover` via `opacity` and `transform: translateY(0)` transitions.

### 5. Metric & KPI Callout Blocks
- Surface `#FFFFFF`, border `1px solid #E5E7EB`, border-radius 10px, padding `20px`.
- Label in `label-md` (`#6B7280`), followed by a prominent 32px numerical KPI in `#2B6CA3` (`font-weight: 700`), followed by a subtle delta or explanatory caption in `#4B5563`.